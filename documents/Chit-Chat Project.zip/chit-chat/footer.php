<style>
	.footer{
		position: fixed;
		bottom: 0px;
		width: 100%;
	}
</style>
<div class="container-fluid p-0">
	<div class="m-5"></div>
	<div class="footer p-3 bg-primary">
		<p class="text-white mb-0 float-right">&copy since 2019</p>
	</div>
</div>